import { Doctor } from "./doctor";

export class Availabledates {

  availabilityId: number;

  doctor: Doctor = new Doctor();
  fromDate: Date;
  endDate: Date;


}
